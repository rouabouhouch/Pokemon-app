#!/usr/bin/env bash
opts=""
test -z "$MONGO_USER" || opts="$opts -u $MONGO_USER"
test -z "$MONGO_PASSWORD" || opts="$opts -p $MONGO_PASSWORD"
mongosh $opts 