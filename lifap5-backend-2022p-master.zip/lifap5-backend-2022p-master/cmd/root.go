/*
Copyright © 2022 Emmanuel Coquery <emmanuel.coquery@univ-lyon1.fr>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
package cmd

import (
	"os"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/config"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "lifap5-backend-2022p",
	Short: "Serveur support pour le projet de LIFAP5 semestre 2022 printemps",
	Long: `Serveur web hébergeant un API REST qui sert pour le projet de LIFAP5
au printemps 2022.

La commande serve permet de lancer le serveur dans sa configuration par défaut:

lifap5-backend-2022p serve
`,
	// Uncomment the following line if your bare application
	// has an action associated with it:
	// Run: func(cmd *cobra.Command, args []string) { },
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	cobra.OnInitialize(config.InitConfig)
	cobra.OnInitialize(initLog)

	// Here you will define your flags and configuration settings.
	// Cobra supports persistent flags, which, if defined here,
	// will be global for your application.

	rootCmd.PersistentFlags().StringVar(&config.CfgFile, "config", "", "config file (default is $HOME/.lifap5-backend-2022p.yaml)")
	rootCmd.PersistentFlags().Bool("debug", false, "enable debug mode")
	viper.BindPFlag("debug", rootCmd.PersistentFlags().Lookup("debug"))
	rootCmd.PersistentFlags().String("mongo-url", "mongodb://localhost/", "URL for connecting to MongoDB")
	viper.BindPFlag("mongo.url", rootCmd.PersistentFlags().Lookup("mongo-url"))
	rootCmd.PersistentFlags().String("mongo-user", "", "Username for connecting to MongoDB")
	viper.BindPFlag("mongo.user", rootCmd.PersistentFlags().Lookup("mongo-user"))
	rootCmd.PersistentFlags().String("mongo-password", "", "Password for connecting to MongoDB")
	viper.BindPFlag("mongo.password", rootCmd.PersistentFlags().Lookup("mongo-password"))

	// Cobra also supports local flags, which will only run
	// when this action is called directly.
	// rootCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}

// Inits configuration of zerolog
func initLog() {
	// Default level for this example is info, unless debug flag is present
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	if viper.GetBool("debug") {
		log.Info().Msg("Enabling debug log level")
		zerolog.SetGlobalLevel(zerolog.DebugLevel)
	}
}
