/*
Copyright © 2022 NAME HERE <EMAIL ADDRESS>

*/
package cmd

import (
	"context"
	"fmt"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/pokedex"
	"github.com/rs/zerolog/log"
	"github.com/spf13/cobra"
)

// loadPokedexCmd represents the loadPokedex command
var loadPokedexCmd = &cobra.Command{
	Use:   "loadPokedex",
	Short: "A brief description of your command",
	Long: `A longer description that spans multiple lines and likely contains examples
and usage of using your command. For example:

Cobra is a CLI library for Go that empowers applications.
This application is a tool to generate the needed files
to quickly create a Cobra application.`,
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) < 1 {
			panic(fmt.Errorf("pokedex file name missing"))
		}
		db, terminate, err := backend.MongoConnect()
		if err != nil {
			log.Err(err).Msg("Failed to connect to MongoDB")
		}
		defer terminate()
		ctx := context.Background()
		err = pokedex.LoadPokemonsFromFile(args[0], db, ctx)
		if err != nil {
			panic(err)
		}
	},
}

func init() {
	rootCmd.AddCommand(loadPokedexCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// loadPokedexCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// loadPokedexCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
