/*
Copyright © 2022 NAME HERE <EMAIL ADDRESS>

*/
package cmd

import (
	"context"
	"fmt"
	"strings"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"github.com/rs/zerolog/log"
	"github.com/spf13/cobra"
)

// keysCmd represents the keys command
var keysCmd = &cobra.Command{
	Use:   "keys",
	Short: "Load users a keys from a file and then writes a keys file and to the keys collection in mongo",
	Long: `Loads a tsv file containing users and keys and then writes 
	a file with keys. The name of the keys file is the basename of the 
	users file with .tsv replaced by .keys. Keys are updated in mongodb 
	according to the values written in the keys file`,
	Run: func(cmd *cobra.Command, args []string) {
		db, terminate, err := backend.MongoConnect()
		if err != nil {
			log.Err(err).Msg("Failed to connect to MongoDB")
		}
		defer terminate()
		ctx := context.Background()
		if len(args) < 1 {
			panic(fmt.Errorf("please specify userId tsv file as an argument"))
		}
		filename := args[0]
		var output string
		if strings.HasSuffix(filename, "tsv") {
			output = filename[:len(filename)-4] + ".keys"
		} else {
			output = filename + ".keys"
		}
		idCol, err := cmd.Flags().GetString("id-col")
		if err != nil {
			log.Err(err).Msg("Failed to get ID column name")
			panic(err)
		}
		keyCol, err := cmd.Flags().GetString("key-col")
		if err != nil {
			log.Err(err).Msg("Failed to get api-key column name")
			panic(err)
		}
		err = backend.LoadMergeWriteKeys(filename, idCol, keyCol, output, db, ctx)
		if err != nil {
			log.Err(err).Msg("Failed to load, merge and write keys")
			panic(err)
		}
	},
}

func init() {
	rootCmd.AddCommand(keysCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// keysCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// keysCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
	keysCmd.Flags().String("id-col", "ID", "ID field in input file")
	keysCmd.Flags().String("key-col", "api-key", "api-key field in input file")
}
