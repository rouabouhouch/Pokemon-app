package web

import (
	"context"
	"io"
	"net/http"
	"strconv"
	"time"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/pokedex"
	"github.com/gin-contrib/cors"
	"github.com/gin-contrib/logger"
	"github.com/gin-gonic/gin"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/mongo"
)

type Toto struct {
	A string
}

// Setups routes
func setupRoutes(r *gin.Engine, db *mongo.Database) {
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	r.POST("/echo", func(c *gin.Context) {
		var data map[string]interface{}
		if err := c.ShouldBindJSON(&data); err != nil {
			c.AbortWithError(http.StatusBadRequest, err)
		} else {
			c.JSON(200, &data)
		}
	})
	r.GET("/whoami", AuthenticationHandler(db), func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"user": c.GetString(CLogin)})
	})
	r.GET("/pokemon", func(c *gin.Context) {
		nameQ := c.Query("name")
		pokemons, err := pokedex.Pokemons(db, context.Background(), nameQ)
		if err != nil {
			c.AbortWithError(http.StatusInternalServerError, err)
		} else {
			c.JSON(http.StatusOK, pokemons)
		}
	})
	r.GET("/pokemon/:id", func(c *gin.Context) {
		id := c.Param("id")
		n, err := strconv.Atoi(id)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusBadRequest,
				gin.H{"message": "cannot convert id to int", "error": err})
			return
		}
		pokemon, err := pokedex.PokemonFromNumber(n, db)
		if err == pokedex.ErrUnknownPokemon {
			c.AbortWithStatusJSON(http.StatusNotFound,
				gin.H{"message": "unknown pokemon", "number": n})
			return
		} else if err != nil {
			c.AbortWithError(http.StatusInternalServerError, err)
			return
		}
		c.JSON(http.StatusOK, pokemon)
	})
	r.GET("/deck/:id", AuthenticationHandler(db), func(c *gin.Context) {
		id := c.Param("id")
		pokemons, err := pokedex.GetUserDeck(id, db, context.Background())
		if err != nil {
			c.AbortWithError(http.StatusInternalServerError, err)
		} else {
			c.JSON(http.StatusOK, pokemons)
		}
	})
	r.POST("/deck", AuthenticationHandler(db), func(c *gin.Context) {
		userId := c.GetString(CLogin)
		var deckContent []int
		err := c.ShouldBindJSON(&deckContent)
		if err != nil {
			c.AbortWithError(http.StatusBadRequest, err)
		} else {
			pokemons, err := pokedex.SetUserDeck(userId, deckContent, db, context.Background())
			if err != nil {
				c.AbortWithError(http.StatusInternalServerError, err)
			} else {
				c.JSON(http.StatusCreated, pokemons)
			}
		}
	})
	r.POST("/fight", AuthenticationHandler(db), func(c *gin.Context) {
		userId := c.GetString(CLogin)
		fightResult, err := pokedex.Fight(userId, db, context.Background())
		if err != nil {
			c.AbortWithError(http.StatusInternalServerError, err)
		} else {
			c.JSON(http.StatusOK, fightResult)
		}
	})
	r.GET("/", func(c *gin.Context) {
		c.File("static/index.html")
	})
	r.GET("/index.html", func(c *gin.Context) {
		c.File("static/index.html")
	})
	r.Static("/client-full", "./react-client/build")
}

// Starts the http server with configured routes.
func Start() {
	db, terminate, err := backend.MongoConnect()
	if err != nil {
		log.Err(err).Msg("Failed to connect to MongoDB")
	}
	defer terminate()
	r := gin.New()
	r.Use(logger.SetLogger(logger.WithLogger(jsonLogger)))
	r.Use(gin.Recovery())
	corsConfig := cors.DefaultConfig()
	corsConfig.AllowAllOrigins = true
	corsConfig.AddAllowHeaders(ApiKeyHeader)
	r.Use(cors.New(corsConfig))
	setupRoutes(r, db)
	r.Run() // listen and serve on 0.0.0.0:8080
}

// Enrichs a Zerolog context with Gin informations.
// Returns the enriched context.
func withGinContext(c *gin.Context, l zerolog.Context) zerolog.Context {
	return l.
		Timestamp().
		Int("status", c.Writer.Status()).
		Str("method", c.Request.Method).
		Str("path", c.Request.URL.Path).
		Str("ip", c.ClientIP()).
		Str("user_agent", c.Request.UserAgent())
}

// Creates a Zerolog context logging in json with additional informations from Gin context.
func jsonLogger(c *gin.Context, out io.Writer, latency time.Duration) zerolog.Logger {
	logger :=
		withGinContext(c, zerolog.New(out).With()).
			Logger()
	return logger
}
