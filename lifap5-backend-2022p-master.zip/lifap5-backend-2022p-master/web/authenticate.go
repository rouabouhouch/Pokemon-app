package web

import (
	"net/http"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"github.com/gin-gonic/gin"
	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/mongo"
)

// HTTP Header holding the api key.
const ApiKeyHeader string = "Api-Key"

// name of the login entry in Gin context.
const CLogin = "login"

// Gin handler for managing API Keys.
// Requires a Mongo database in order to look for api the the keys collection.
// Puts the login information into Gin context at entry CLogin.
func AuthenticationHandler(db *mongo.Database) gin.HandlerFunc {
	return func(c *gin.Context) {
		l := withGinContext(c, log.With()).Logger()
		apiKey, keyPresent := c.Request.Header[ApiKeyHeader]
		if keyPresent {
			login, err := backend.UserFromKey(apiKey[0], db)
			if err == backend.ErrUnknownApiKey { // Mauvaise clé
				l.Info().Msg(ApiKeyHeader + " inconnu")
				c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"message": ApiKeyHeader + " inconnu"})
			} else if err != nil { // Erreur interne
				l.Err(err).Msg("Erreur interne lors de la recherche de clé d'API")
				c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{"message": "Erreur interne"})
			} else { // Authentification réussie, on pousse le login dans le contexte et on passe à la suite
				c.Set(CLogin, login)
				c.Next()
			}
		} else { // No api key
			l.Info().Msg("Pas de clé d'API")
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"message": ApiKeyHeader + " requis"})
		}
	}
}
