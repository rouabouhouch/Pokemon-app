package web

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/config"
	"github.com/gin-gonic/gin"
	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"gotest.tools/v3/assert"
)

// Fixtures
var user1 backend.User = backend.User{Key: "key1", Login: "user1"}

func ensureUsers(db *mongo.Database) error {
	keys := db.Collection(backend.KeysC)
	var existingUser backend.User
	if err := keys.FindOne(context.TODO(), bson.M{"login": user1.Login}).Decode(&existingUser); err != nil {
		log.Debug().Err(err).Msg("Inserting user")
		_, err = keys.InsertOne(context.TODO(), user1)
		if err != nil {
			return err
		}
	}
	return nil
}

func init() {
	config.InitConfig()
}

// Tests

func TestPingRoute(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	assert.Assert(t, db != nil)
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/ping", nil)
	r.ServeHTTP(w, req)

	assert.Equal(t, 200, w.Code)
	var data map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &data)
	assert.Equal(t, "pong", data["message"].(string))
}

func TestWhoamiNoHeader(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/whoami", nil)
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestWhoamiHeaderWrong(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := "nosuchkey"
	assert.Assert(t, key != user1.Key) // change by looking up in db
	req, _ := http.NewRequest("GET", "/whoami", nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusUnauthorized, w.Code)
}
func TestWhoamiHeaderRight(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	err = ensureUsers(db)
	assert.NilError(t, err)
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := user1.Key
	req, _ := http.NewRequest("GET", "/whoami", nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)

	assert.Equal(t, http.StatusOK, w.Code)
	var data map[string]interface{}
	body := w.Body.Bytes()
	log.Info().Bytes("body", w.Body.Bytes()).Msg("body")
	err = json.Unmarshal(body, &data)
	assert.NilError(t, err)
	l, ok := data["user"]
	assert.Assert(t, ok, "No user in json")
	assert.Equal(t, user1.Login, l.(string))
}

func TestForbiddenDeckAccess(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := "nosuchkey"
	assert.Assert(t, key != user1.Key) // change by looking up in db
	req, _ := http.NewRequest("GET", "/deck/"+user1.Login, nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusUnauthorized, w.Code)
	req, _ = http.NewRequest("POST", "/deck", nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestAllowedDeckAccess(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	err = ensureUsers(db)
	assert.NilError(t, err)
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := user1.Key
	req, _ := http.NewRequest("GET", "/deck/"+user1.Login, nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
	sentPokemons := []int{2, 19, 27}
	rawSentData, err := json.Marshal(sentPokemons)
	assert.NilError(t, err, "Failed to build JSON data")
	w = httptest.NewRecorder()
	req, _ = http.NewRequest("POST", "/deck", bytes.NewReader(rawSentData))
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusCreated, w.Code)
	var returnedData []int
	err = json.Unmarshal(w.Body.Bytes(), &returnedData)
	assert.NilError(t, err)
	assert.DeepEqual(t, sentPokemons, returnedData)
}

func TestForbiddenFight(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := "nosuchkey"
	assert.Assert(t, key != user1.Key) // change by looking up in db
	req, _ := http.NewRequest("POST", "/fight", nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusUnauthorized, w.Code)
}

func TestAllowedFight(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Mongo connection failed")
	defer terminate()
	r := gin.Default()
	setupRoutes(r, db)
	w := httptest.NewRecorder()
	key := user1.Key
	req, _ := http.NewRequest("POST", "/fight", nil)
	req.Header[ApiKeyHeader] = []string{key}
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)

}
