import "./App.css";
import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowDown,
  faArrowUp,
  faSearch,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import "bulma/css/bulma.min.css";
import {
  Button,
  Navbar,
  Modal,
  Form,
  Heading,
  Card,
  Media,
  Image,
  Content,
  Table,
  Icon,
  Columns,
  Tabs,
} from "react-bulma-components";
import { BrowserRouter as Router } from "react-router-dom";

const ApiKeyHeaderName = "Api-Key";
const Logo =
  "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/025.png";

/**
 * Sets the Api-Key header the the request will be authenticated, if the key is
 * set if the connexionState.
 * @param {Headers} headers the headers for fetch
 * @param {*} connexionState the connexion part of the state object
 */
function setAPIKeyHeader(headers, connexionState) {
  if (connexionState.key) {
    headers.set(ApiKeyHeaderName, connexionState.key);
  }
}

function whoamiReq(connexionState) {
  if (connexionState.key) {
    let headers = new Headers();
    setAPIKeyHeader(headers, connexionState);
    return fetch(connexionState.server + "/whoami", { headers: headers })
      .then((req) => {
        if (req.status === 200) {
          return req.json();
        } else if (req.status === 401) {
          return Promise.reject("Unknown key, unauthorized");
        } else {
          return Promise.reject("Unexpected status :" + req.status);
        }
      })
      .then((json) => {
        return json.user;
      });
  } else {
    return Promise.reject("API key not set");
  }
}

function pokemonReq(connexionState) {
  return fetch(connexionState.server + "/pokemon").then((req) => {
    if (req.status === 200) {
      return req.json();
    } else {
      return Promise.reject(
        "Erreur " +
          req.status +
          ", impossible de récupérer la liste des pokemons"
      );
    }
  });
}

function onePokemonReq(connexionState, id) {
  return fetch(connexionState.server + "/pokemon/" + id).then((req) => {
    if (req.status === 200) {
      return req.json();
    } else {
      return Promise.reject(
        "Erreur " + req.status + ", impossible de récupérer le pokemon " + id
      );
    }
  });
}

function getDeckContentReq(connexionState, id) {
  if (connexionState.key) {
    let headers = new Headers();
    setAPIKeyHeader(headers, connexionState);
    return fetch(connexionState.server + "/deck/" + id, {
      headers: headers,
    }).then((req) => {
      if (req.status === 200) {
        return req.json();
      } else if (req.status === 401) {
        return Promise.reject("Unknown key, unauthorized");
      } else {
        return Promise.reject("Unexpected status :" + req.status);
      }
    });
  } else {
    return Promise.reject("API key not set");
  }
}

function putDeckContentReq(connexionState, content) {
  if (connexionState.key) {
    let headers = new Headers();
    setAPIKeyHeader(headers, connexionState);
    headers.set("Content-Type", "application/json");
    return fetch(connexionState.server + "/deck", {
      headers: headers,
      body: JSON.stringify(content),
      method: "POST",
    }).then((req) => {
      if (req.status === 201) {
        return req.json();
      } else if (req.status === 401) {
        return Promise.reject("Unknown key, unauthorized");
      } else {
        return Promise.reject("Unexpected status :" + req.status);
      }
    });
  } else {
    return Promise.reject("API key not set");
  }
}

function fightReq(connexionState) {
  if (connexionState.key) {
    let headers = new Headers();
    setAPIKeyHeader(headers, connexionState);
    //headers.set("Content-Type", "application/json");
    return fetch(connexionState.server + "/fight", {
      headers: headers,
      //body: JSON.stringify(content),
      method: "POST",
    }).then((req) => {
      if (req.status === 200) {
        return req.json();
      } else if (req.status === 401) {
        return Promise.reject("Unknown key, unauthorized");
      } else {
        return Promise.reject("Unexpected status :" + req.status);
      }
    });
  } else {
    return Promise.reject("API key not set");
  }
}

/**
 * Main entry point for the application
 */
class App extends React.Component {
  /**
   * Contructor
   * @param {*} props properties used when instanciating the component
   */
  constructor(props) {
    super(props);
    this.state = {
      connexion: {
        key: "",
        modal: false,
        // server: "http://localhost:8080",
        server: "https://lifap5.univ-lyon1.fr",
        user: "",
      },
      message: { show: false, message: "" },
      pokemonNumbers: [],
      pokemons: [],
      pokemon: null,
      mesPokemons: [],
      search: "",
      page: "pokedex",
    };
    this.loadPokemonNumbers();
    // this.proceedWithConnexion(); // only for testing
  }

  goToPokedex() {
    this.setState({ pokemon: null, search: "", page: "pokedex" });
  }

  goToFight() {
    console.log("go to fight");
    this.setState({ search: "", page: "fight" });
  }

  getFightOrMessage() {
    return fightReq(this.state.connexion).catch((err) => {
      this.showMessage(String(err));
      return Promise.reject("Failed to get fight info");
    });
  }

  loadPokemonNumbers() {
    pokemonReq(this.state.connexion).then(
      (pokemons) => {
        pokemons.sort(
          (x, y) => Number(x.PokedexNumber) - Number(y.PokedexNumber)
        );
        this.setState({
          pokemonNumbers: pokemons.map((p) => p.PokedexNumber),
          pokemons: pokemons,
          pokemon: pokemons[0],
        });
      },
      (err) => this.showMessage(String(err))
    );
  }

  showPokemon(n) {
    onePokemonReq(this.state.connexion, n).then(
      (pokemon) => this.setState({ pokemon: pokemon }),
      (err) => this.showMessage(String(err))
    );
  }

  /**
   * Hides the message box
   */
  hideMessage() {
    this.setState({ message: { ...this.state.message, show: false } });
  }

  /**
   * Triggers the display of a message.
   * @param {String} msg The message to display.
   */
  showMessage(msg) {
    this.setState({
      message: { ...this.state.message, show: true, message: msg },
    });
  }

  /**
   * Callback to be used when the connexion button is clicked.
   */
  connexionClicked() {
    if (this.state.connexion.key === "") {
      if (this.state.connexion.modal) {
        console.log("Hide connection modal");
        this.setState({ connexion: { ...this.state.connexion, modal: false } });
      } else {
        console.log("Show connection modal");
        this.setState({ connexion: { ...this.state.connexion, modal: true } });
      }
    } else {
      console.log("Disconnect");
      this.setState({
        connexion: { ...this.state.connexion, key: "", modal: false, user: "" },
        mesPokemons: [],
      });
    }
  }

  /**
   * Updates the API key value
   * @param {*} k new value for API key
   */
  updateAPIKey(k) {
    // console.log(`Update API Key with ${k}`);
    this.setState({ connexion: { ...this.state.connexion, key: k } });
  }

  /**
   * callback used to hide the connection modal and abort the connexion process.
   */
  abortConnexion() {
    console.log("Aborting connection");
    this.setState({
      connexion: { ...this.state.connexion, key: "", modal: false, user: "" },
    });
  }

  loadMyPokemons() {
    console.log("get my pokemons");
    getDeckContentReq(this.state.connexion, this.state.connexion.user).then(
      (pokemons) => {
        this.setState({ mesPokemons: pokemons });
      },
      (err) => {
        this.showMessage("Failed to load my pokemons: " + err);
      }
    );
  }

  addPokemonToDeck(pNum) {
    console.log("Add pokemon " + pNum + " to deck");
    let newDeck = this.state.mesPokemons.slice(0);
    newDeck.push(pNum);
    putDeckContentReq(this.state.connexion, newDeck).then(
      (pList) => {
        this.setState({ mesPokemons: pList });
      },
      (err) => {
        this.showMessage("Failed to change deck: " + err);
      }
    );
  }

  removePokemonFromDeck(pNum) {
    console.log("Remove pokemon " + pNum + " from deck");
    let newDeck = this.state.mesPokemons.filter((n) => n !== pNum);
    putDeckContentReq(this.state.connexion, newDeck).then(
      (pList) => {
        this.setState({ mesPokemons: pList });
      },
      (err) => {
        this.showMessage("Failed to change deck: " + err);
      }
    );
  }

  /**
   * callback used to try to connect.
   * TODO: do trigger the connection attempt.
   */
  proceedWithConnexion() {
    console.log("proceed with connection");
    whoamiReq(this.state.connexion).then(
      (user) => {
        console.log("Logged in with user " + user);
        this.setState({ connexion: { ...this.state.connexion, user: user } });
        this.loadMyPokemons();
      },
      (err) => {
        console.log("Failed to connect: " + err);
        this.setState({
          connexion: { ...this.state.connexion, user: "", key: "" },
        });
        this.showMessage(String(err));
      }
    );
    this.setState({ connexion: { ...this.state.connexion, modal: false } });
  }

  updateSearch(search) {
    this.setState({ search: search });
  }

  renderPokedex() {
    return (
      <Columns>
        <Columns.Column>
          <PokemonTable
            pokemons={this.state.pokemons}
            viewCallback={(n) => this.showPokemon(n)}
            search={this.state.search}
            shownPokemonNumber={
              this.state.pokemon ? this.state.pokemon.PokedexNumber : -1
            }
            mesPokemons={this.state.mesPokemons}
          ></PokemonTable>
        </Columns.Column>
        <Columns.Column>
          {this.state.pokemon ? (
            <PokemonCard
              pokemon={this.state.pokemon}
              mesPokemons={this.state.mesPokemons}
              connecte={this.state.connexion.user !== ""}
              addPokemon={(n) => this.addPokemonToDeck(n)}
              removePokemon={(n) => this.removePokemonFromDeck(n)}
            ></PokemonCard>
          ) : (
            []
          )}
        </Columns.Column>
      </Columns>
    );
  }

  renderFight() {
    return (
      <PokemonFight
        getFight={() => this.getFightOrMessage()}
        pokemons={this.state.pokemons}
      ></PokemonFight>
    );
  }

  renderPage() {
    if (this.state.search) {
      return this.renderPokedex();
    }
    switch (this.state.page) {
      case "fight":
        return this.renderFight();
      case "pokedex":
      default:
        return this.renderPokedex();
    }
  }

  render() {
    return (
      <Router basename={"/client-full"}>
        <div className="App">
          <BarreHaut
            connexionState={this.state.connexion}
            connexionButtonClicked={() => this.connexionClicked()}
            goHome={() => this.goToPokedex()}
            goFight={() => this.goToFight()}
            updateSearch={(s) => this.updateSearch(s)}
            search={this.state.search}
          ></BarreHaut>
          {this.renderPage()}
          <ConnexionModal
            apikey={this.state.connexion.key}
            show={this.state.connexion.modal}
            abort={() => this.abortConnexion()}
            proceed={() => this.proceedWithConnexion()}
            updateKey={(k) => this.updateAPIKey(k)}
          ></ConnexionModal>
          <MessageDisplay
            show={this.state.message.show}
            onClose={() => this.hideMessage()}
            message={this.state.message.message}
          ></MessageDisplay>
        </div>
      </Router>
    );
  }
}

/**
 * Top navigation bar
 */
class BarreHaut extends React.Component {
  render() {
    let connexionLabel =
      this.props.connexionState.key !== "" ? "Déconnexion" : "Connexion";
    return (
      <div>
        <Navbar>
          <Navbar.Brand>
            <Navbar.Item onClick={this.props.goHome}>
              <img alt="Home" src={Logo} />
            </Navbar.Item>
          </Navbar.Brand>
          <Navbar.Menu>
            <Navbar.Container>
              <Navbar.Item>
                <Form.Field>
                  <Form.Control>
                    <Form.Input
                      onChange={(e) => this.props.updateSearch(e.target.value)}
                      value={this.props.search}
                      placeholder="Chercher un pokemon"
                      type="text"
                    />
                    <Icon align="left">
                      <FontAwesomeIcon icon={faSearch} />
                    </Icon>
                  </Form.Control>
                </Form.Field>
              </Navbar.Item>
              <Navbar.Item onClick={this.props.goHome}>Pokedex</Navbar.Item>
              <Navbar.Item onClick={this.props.goFight}>Combat</Navbar.Item>
            </Navbar.Container>
            <Navbar.Container align="end">
              <Navbar.Item>
                <Content>&nbsp;</Content>
                <Content>
                  <span>{this.props.connexionState.user}</span>
                </Content>
              </Navbar.Item>
            </Navbar.Container>
            <Navbar.Container align="end">
              <Navbar.Item>
                <Button onClick={() => this.props.connexionButtonClicked()}>
                  <Icon>
                    <FontAwesomeIcon icon={faUser} />
                  </Icon>
                  <span>{connexionLabel}</span>
                </Button>
              </Navbar.Item>
            </Navbar.Container>
          </Navbar.Menu>
        </Navbar>
      </div>
    );
  }
}

/**
 * Connexion modal
 */
class ConnexionModal extends React.Component {
  render() {
    return (
      <Modal show={this.props.show} onClose={() => this.props.abort()}>
        <Modal.Card>
          <Modal.Card.Header>
            <Modal.Card.Title>Connexion</Modal.Card.Title>
          </Modal.Card.Header>
          <Modal.Card.Body>
            <Form.Field>
              <Form.Label>Clé d'API</Form.Label>
              <Form.Input
                value={this.props.apikey}
                onChange={(e) => {
                  this.props.updateKey(e.target.value);
                }}
              ></Form.Input>
            </Form.Field>
          </Modal.Card.Body>
          <Modal.Card.Footer align="right">
            <Button onClick={() => this.props.abort()}>Annuler</Button>
            <Button onClick={() => this.props.proceed()} color="success">
              Valider
            </Button>
          </Modal.Card.Footer>
        </Modal.Card>
      </Modal>
    );
  }
}

/** Message modal */
class MessageDisplay extends React.Component {
  render() {
    return (
      <Modal
        show={this.props.show}
        onClose={() => this.props.onClose()}
        showClose="true"
      >
        <Modal.Content>{this.props.message}</Modal.Content>
      </Modal>
    );
  }
}

/** Table pour afficher une liste de pokemons avec des capacités de filtre */
class PokemonTable extends React.Component {
  /**
   * Contructor
   * @param {*} props properties used when instanciating the component
   */
  constructor(props) {
    super(props);
    this.state = {
      sort: "PokedexNumber",
      sortAsc: 1,
      columns: ["Image", "PokedexNumber", "Name", "Abilities", "Types"],
      limit: 10,
      aliases: { Image: "", PokedexNumber: "#" },
      tab: "all",
    };
  }
  pokemonCmp(p1, p2) {
    let c = this.state.sort;
    let base = p1[c] < p2[c] ? -1 : p1[c] > p2[c] ? 1 : 0;
    return this.state.sortAsc * base;
  }
  pokemonsToShow() {
    let pokemons = this.props.pokemons;
    pokemons = pokemons.slice(0);
    if (this.state.tab === "my") {
      pokemons = pokemons.filter((p) =>
        this.props.mesPokemons.some((n) => n === p.PokedexNumber)
      );
    }
    if (this.props.search) {
      pokemons = pokemons.filter(
        (p) =>
          p.Name.toLowerCase().indexOf(this.props.search.toLowerCase()) >= 0
      );
    }
    pokemons.sort((p1, p2) => this.pokemonCmp(p1, p2));
    pokemons = pokemons.slice(0, this.state.limit);
    return pokemons;
  }
  clickOnHeader(col) {
    if (this.state.sort === col) {
      this.setState({ sortAsc: -1 * this.state.sortAsc });
    } else {
      this.setState({ sort: col, sortAsc: 1 });
    }
  }
  showMore() {
    this.setState({ limit: this.state.limit + 10 });
  }
  renderOneTab(name, display) {
    return (
      <Tabs.Tab
        active={name === this.state.tab}
        onClick={() => this.setState({ tab: name })}
      >
        {display}
      </Tabs.Tab>
    );
  }
  renderTabs() {
    return (
      <Tabs>
        {this.renderOneTab("all", "Tous les pokemons")}
        {this.renderOneTab("my", "Mes pokemons")}
      </Tabs>
    );
  }
  renderImage(pokemon) {
    return (
      <Vignette
        pokemon={pokemon}
        onClick={() => this.props.viewCallback(pokemon.PokedexNumber)}
      />
    );
  }
  renderTextWithClick(pokemon, text) {
    return <Content>{text}</Content>;
  }
  renderCell(pokemon, col) {
    if (col === "Image") {
      return this.renderImage(pokemon);
    } else if (col === "PokedexNumber") {
      return this.renderTextWithClick(pokemon, pokemon.PokedexNumber);
    } else if (col === "Abilities" || col === "Types") {
      return (
        <ul>
          {pokemon[col].map((a) => (
            <li>{a}</li>
          ))}
        </ul>
      );
    } else {
      return <Content>{pokemon[col]}</Content>;
    }
  }
  renderLine(pokemon) {
    const selected =
      pokemon.PokedexNumber === this.props.shownPokemonNumber
        ? "is-selected"
        : "";
    return (
      <tr
        onClick={() => this.props.viewCallback(pokemon.PokedexNumber)}
        className={selected}
      >
        {this.state.columns.map((c) => (
          <td>{this.renderCell(pokemon, c)}</td>
        ))}
      </tr>
    );
  }
  renderShowMore() {
    if (this.props.pokemons.length > this.state.limit) {
      return <Button onClick={() => this.showMore()}>More</Button>;
    } else {
      return [];
    }
  }
  renderHeader(col) {
    let icon = [];
    if (col === this.state.sort) {
      if (this.state.sortAsc > 0) {
        icon = [
          <Icon>
            <FontAwesomeIcon icon={faArrowUp} />
          </Icon>,
        ];
      } else {
        icon = (
          <Icon>
            <FontAwesomeIcon icon={faArrowDown} />
          </Icon>
        );
      }
    }
    return (
      <th onClick={() => this.clickOnHeader(col)}>
        <span>{this.state.aliases[col] || col}</span>
        {icon}
      </th>
    );
  }
  render() {
    const toShow = this.pokemonsToShow();
    if (toShow.length > 0) {
      return (
        <div>
          {this.renderTabs()}
          <Table>
            <thead>
              <tr>{this.state.columns.map((c) => this.renderHeader(c))}</tr>
            </thead>
            <tbody>{toShow.map((p) => this.renderLine(p))}</tbody>
          </Table>
          {this.renderShowMore()}
        </div>
      );
    } else {
      return (
        <div>
          {this.renderTabs()}
          <p>Pas de pokemon à afficher</p>
        </div>
      );
    }
  }
}

/** Composant pour afficher un pokemon */
class PokemonCard extends React.Component {
  render() {
    const mesPokemons = this.props.mesPokemons;
    const connecte = this.props.connecte;
    const pokemon = this.props.pokemon;
    const resistant = Object.keys(pokemon.Against).filter(
      (p) => pokemon.Against[p] < 1
    );
    const weak = Object.keys(pokemon.Against).filter(
      (p) => pokemon.Against[p] > 1
    );
    let myPokemonButton = <div></div>;
    if (connecte) {
      if (mesPokemons.indexOf(pokemon.PokedexNumber) >= 0) {
        myPokemonButton = (
          <Button
            color={"danger"}
            onClick={() => this.props.removePokemon(pokemon.PokedexNumber)}
          >
            Retirer de mon deck
          </Button>
        );
      } else {
        myPokemonButton = (
          <Button
            color={"success"}
            onClick={() => this.props.addPokemon(pokemon.PokedexNumber)}
          >
            Ajouter à mon deck
          </Button>
        );
      }
    }
    if (pokemon) {
      return (
        <Card>
          <Card.Header>
            <Card.Header.Title>
              {pokemon.JapaneseName} (#{pokemon.PokedexNumber})
            </Card.Header.Title>
          </Card.Header>
          <Card.Content>
            <Media>
              <Media.Item>
                <Heading>{pokemon.Name}</Heading>
                <Heading subtitle>{pokemon.Classification}</Heading>
              </Media.Item>
            </Media>
          </Card.Content>
          <Card.Content>
            <Media>
              <Media.Item>
                <Content textAlign={"left"}>
                  <p>Hit points: {pokemon.Hp}</p>
                  <h3>Abilities</h3>
                  <ul>
                    {pokemon.Abilities.map((a) => (
                      <li>{a}</li>
                    ))}
                  </ul>
                  <h3>Resistant against</h3>
                  <ul>
                    {resistant.map((p) => (
                      <li>{p}</li>
                    ))}
                  </ul>
                  <h3>Weak against</h3>
                  <ul>
                    {weak.map((p) => (
                      <li>{p}</li>
                    ))}
                  </ul>
                </Content>
              </Media.Item>
              <Media.Item renderAs="figure" align="right">
                <Image
                  size={475}
                  alt={pokemon.Name}
                  src={pokemon.Images.Full}
                />
              </Media.Item>
            </Media>
          </Card.Content>
          <Card.Footer>
            <Media>
              <Media.Item>{myPokemonButton}</Media.Item>
            </Media>
          </Card.Footer>
        </Card>
      );
    }
  }
}

class PokemonFight extends React.Component {
  /**
   * Contructor
   * @param {*} props properties used when instanciating the component
   */
  constructor(props) {
    super(props);
    this.state = {
      started: false,
      finished: false,
      leftIdx: -1,
      rightIdx: -1,
      fightData: undefined,
      round: -1,
      pause: 1000,
    };
  }
  simulationStep() {
    console.log("step", this.state.round);
    if (this.state.round < this.state.fightData.Rounds.length) {
      this.setState({ round: this.state.round + 1 });
      setTimeout(() => this.simulationStep(), this.state.pause);
    } else {
      this.setState({ finished: true });
    }
  }
  simulation() {
    this.props.getFight().then((fight) => {
      console.log(fight);
      this.setState({
        started: true,
        finished: false,
        leftIdx: 0,
        rightIdx: 0,
        fightData: fight,
        round: 0,
      });
      setTimeout(() => this.simulationStep(), this.state.pause);
    });
  }
  renderFinished() {
    return (
      <Content>
        <p>
          Vous avez {this.state.fightData.Winner === "left" ? "gagné" : "perdu"}
        </p>
        <Button onClick={() => this.simulation()} color={"info"}>
          Démarrer un autre combat
        </Button>
      </Content>
    );
  }
  renderSingleRound(r) {
    const left = (
      <Vignette pokemon={this.props.pokemons[r.Left]} onClick={() => 0} />
    );
    const right = (
      <Vignette pokemon={this.props.pokemons[r.Right]} onClick={() => 0} />
    );
    if (r.AttackFrom === "left") {
      return [
        // <Columns vCentered>
        //   <Columns.Column>{left}</Columns.Column>
        //   <Columns.Column size={2}>attaque</Columns.Column>
        //   <Columns.Column>{right}</Columns.Column>
        //   <Columns.Column size={8}>
        //     avec une attaque de type {r.Type} et fait {r.Damage} points de
        //     dégâts.
        //   </Columns.Column>
        // </Columns>,
        <Media>
          <Media.Item>
            {left} attaque {right} avec une attaque de type {r.Type} et fait{" "}
            {r.Damage} points de dégâts.
          </Media.Item>
        </Media>,
        r.KO ? (
          <Media>
            <Media.Item>{right} est KO</Media.Item>
          </Media>
        ) : (
          []
        ),
      ];
    } else {
      return [
        <Media>
          <Media.Item>
            {left} est attaqué par {right} avec une attaque de type {r.Type} qui
            lui fait {r.Damage} points de dégâts.
          </Media.Item>
        </Media>,
        r.KO ? (
          <Media>
            <Media.Item>{left} est KO</Media.Item>
          </Media>
        ) : (
          []
        ),
      ];
    }
  }
  renderRounds() {
    return this.state.fightData.Rounds.slice(
      this.state.round,
      this.state.round + 1
    ).map((r) => this.renderSingleRound(r));
  }
  renderSimulation() {
    return (
      <Content>
        <div>{this.renderRounds()}</div>
        {this.state.finished ? this.renderFinished() : []}
      </Content>
    );
  }
  renderDemarrer() {
    return (
      <Content alignItems="center">
        <Button onClick={() => this.simulation()} color={"info"}>
          Démarrer un combat
        </Button>
      </Content>
    );
  }
  renderEmptyOrFight() {
    if (this.state.started) {
      return this.renderSimulation();
    } else {
      return this.renderDemarrer();
    }
  }
  render() {
    return (
      <div>
        <Heading>Combat</Heading>
        {this.renderEmptyOrFight()}
      </div>
    );
  }
}

class Vignette extends React.Component {
  render() {
    return (
      <img
        width={64}
        alt={this.props.pokemon.Name}
        src={this.props.pokemon.Images.Detail}
        onClick={this.props.onClick}
      />
    );
  }
}

export default App;
