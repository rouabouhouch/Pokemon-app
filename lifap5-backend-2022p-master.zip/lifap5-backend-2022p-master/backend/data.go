package backend

import (
	"context"

	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// Mongo database name
var DBName string = "lifap5"

// Connects to the Mongo database.
// Uses viper confing to get connection parameters.
// On success a handle to the DB and a disconnection function are returned.
// On failure the reason is returned as an error.
func MongoConnect() (*mongo.Database, func(), error) {
	url := viper.GetString("mongo.url")
	user := viper.GetString("mongo.user")
	password := viper.GetString("mongo.password")
	clientOps := options.Client().ApplyURI(url)
	if user != "" {
		clientOps = clientOps.SetAuth(options.Credential{
			AuthSource: "admin", Username: user, Password: password})
	}
	client, err := mongo.Connect(context.TODO(), clientOps)
	if err != nil {
		log.Err(err).Msg("Failed to connect to Mongo")
		return nil, nil, err
	}
	log.Debug().Str("mongourl", url).Msg("Connecting to MongoDB")
	terminate := func() {
		if err = client.Disconnect(context.TODO()); err != nil {
			panic(err)
		}
	}
	db := client.Database(DBName)
	return db, terminate, err
}
