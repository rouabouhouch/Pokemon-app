package backend

import (
	"context"
	"testing"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/config"
	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
	"go.mongodb.org/mongo-driver/bson"
	"gotest.tools/v3/assert"
)

func init() {
	config.InitConfig()
}

func TestMongoConnect(t *testing.T) {
	url := viper.GetString("mongo.url")
	user := viper.GetString("mongo.user")
	log.Debug().Str("mongourl", url).Str("mongouser", user).Msg("Mongo infos")
	db, terminate, err := MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	_, err = db.ListCollectionNames(context.TODO(), bson.D{})
	assert.NilError(t, err, "Failed to list Mongo collections")
	defer terminate()
}
