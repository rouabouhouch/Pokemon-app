package backend

import (
	"testing"

	"gotest.tools/v3/assert"
)

func TestLoadTomuss(t *testing.T) {
	users, err := loadUsersFromCSV("../data/student_list.tsv",
		"ID", ".cle_api", '\t')
	assert.NilError(t, err)
	assert.Equal(t, 147, len(users))
}
