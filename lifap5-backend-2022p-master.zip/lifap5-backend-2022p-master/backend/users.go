package backend

import (
	"context"
	"errors"

	"github.com/google/uuid"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// Struct for representing users with their apiKeys.
type User struct {
	// The user's api key.
	Key string
	// The username.
	Login string
}

// Error returned when an apiKey is not found in the keys collection
var ErrUnknownApiKey error = errors.New("unknown API Key")

// Collection where api keys are stored
const KeysC string = "keys"

// Lookup apiKey in the "keys" collection in MongoDB.
// If the apiKey is found then it is returned with a nil error.
// If the apiKey is not found  (nil,ErrUnknownApiKey) is returned.
// If an error occurs during the MongoDB query, it is returned.
func UserFromKey(apiKey string, db *mongo.Database) (string, error) {
	keys := db.Collection(KeysC)
	var user User
	err := keys.FindOne(context.TODO(), bson.M{"key": apiKey}, options.FindOne()).Decode(&user)
	if err == mongo.ErrNoDocuments {
		return "", ErrUnknownApiKey
	}
	if err != nil {
		return "", err
	}
	return user.Login, nil
}

// If user is not in db and has a key, creates a new one based on user.
// If user is not in db and has no key generates a new key and insert the user in db
// If the user has a key and is in db, the db is updated
// If the user has no key and is in db, the key is retreived fro mthe db
// Returns the user as it is now in the db
func mergeUser(user User, db *mongo.Database, ctx context.Context) (User, error) {
	keys := db.Collection(KeysC)
	var user2 User
	err := keys.FindOne(ctx, bson.M{"login": user.Login}).Decode(&user2)
	if err == mongo.ErrNoDocuments { // user not in db
		if user.Key == "" { // no key in user
			newKey, err := uuid.NewRandom()
			if err != nil {
				return user, err
			}
			user2 = User{Login: user.Login, Key: newKey.String()}
		} else { // user has a key
			user2 = user
		}
		_, err = keys.InsertOne(ctx, user2, &options.InsertOneOptions{})
		return user2, err
	} else { // user is in db
		if user.Key != user2.Key && user.Key != "" { // user has a key and it's different from db
			// update db
			res := keys.FindOneAndReplace(ctx, user2, user, &options.FindOneAndReplaceOptions{})
			if res.Err() != nil {
				return user, err
			}
			return user, nil
		} else if user.Key != user2.Key && user.Key == "" {
			return user2, nil // key in db is ok, keep it and return it
		} else if user.Key == user2.Key && user.Key == "" {
			newKey, err := uuid.NewRandom()
			if err != nil {
				return user, err
			}
			user2 = User{Login: user.Login, Key: newKey.String()}
			res := keys.FindOneAndReplace(ctx, bson.M{"login": user.Login}, user2, &options.FindOneAndReplaceOptions{})
			if res.Err() != nil {
				return user, err
			}
			return user2, nil
		} else { // same non empty key for user and in db, keep things as they are
			return user2, nil
		}
	}
}
