package backend

import (
	"context"
	"encoding/csv"
	"errors"
	"os"
	"regexp"
	"strings"

	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/mongo"
)

var ErrIdColNotFound error = errors.New("tomuss id col not found")
var ErrKeyColNotFound error = errors.New("tomuss key col not found")

const DefaultTomussId string = "ID"

var StudentIdRegexp *regexp.Regexp = regexp.MustCompile("^[0-9]{8}$")
var StudentLoginRegexp *regexp.Regexp = regexp.MustCompile("^[px][0-9]{7}$")

func normalizeId(id string) string {
	originalId := strings.Trim(id, " ")
	if StudentIdRegexp.MatchString(originalId) {
		if originalId[0] == '1' {
			return "p" + originalId[1:]
		} else {
			return "x" + originalId[1:]
		}
	}
	return originalId
}

// true if the login matches the regxp of students login, e.g. p1234567
func isStudentLogin(login string) bool {
	return StudentLoginRegexp.MatchString(login)
}

// finds the position of the login field, the key field or error is not nil
func findLoginKeyIdx(header []string, loginField string, keyField string, filename string) (loginIdx int, keyIdx int, err error) {
	foundLogin := false
	foundKey := false
	loginIdx = -1
	keyIdx = -1
	for i, f := range header {
		if f == loginField {
			foundLogin = true
			loginIdx = i
		}
		if f == keyField {
			foundKey = true
			keyIdx = i
		}
	}
	if !foundKey {
		err = ErrKeyColNotFound
		log.Err(err).Str("column", keyField).Str("file", filename).Msg("Could not find api-key column")
	} else if !foundLogin {
		log.Err(err).Str("column", loginField).Str("file", filename).Msg("Could not find ID column")
		err = ErrIdColNotFound
	}
	return
}

// Loads a csv file containing logins and keys and fill a User array
//
// filename is the file to read.
// loginField and keyField indicate the fields to be used for login and key.
// separator is the separator character (e.g. , or \t)
func loadUsersFromCSV(filename string, loginField string, keyField string, separator rune) ([]User, error) {
	result := make([]User, 0)
	file, err := os.Open(filename)
	if err != nil {
		return result, err
	}
	defer file.Close()
	csvReader := csv.NewReader(file)
	csvReader.Comma = separator
	data, err := csvReader.ReadAll()
	if err != nil {
		return result, err
	}
	loginIdx, keyIdx, err := findLoginKeyIdx(data[0], loginField, keyField, filename)
	if err != nil {
		return result, err
	}
	for _, row := range data[1:] {
		if keyIdx < len(row) {
			result = append(result, User{
				Login: normalizeId(row[loginIdx]),
				Key:   strings.Trim(row[keyIdx], " ")})
		} else {
			result = append(result, User{
				Login: normalizeId(row[loginIdx]),
				Key:   ""})
		}
	}
	return result, err
}

// Writes an array of users to a tsv file with user\tapi-key on each line
func writeKeysFile(filename string, users []User) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	writer.Comma = '\t'
	for _, u := range users {
		err = writer.Write([]string{u.Login, u.Key})
		if err != nil {
			return err
		}
	}
	writer.Flush()
	return nil
}

// loads a key file, merge with the db and writes keys to a keys file
func LoadMergeWriteKeys(
	inputFile string, idCol string, keyCol string,
	outputFile string,
	db *mongo.Database, ctx context.Context) error {
	users, err := loadUsersFromCSV(inputFile, idCol, keyCol, '\t')
	if err != nil {
		return err
	}
	newUsers := make([]User, 0)
	for _, u := range users {
		newU, err := mergeUser(u, db, ctx)
		if err != nil {
			return err
		}
		newUsers = append(newUsers, newU)
	}
	err = writeKeysFile(outputFile, newUsers)
	return err
}
