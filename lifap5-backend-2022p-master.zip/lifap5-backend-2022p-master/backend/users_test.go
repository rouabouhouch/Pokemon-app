package backend

import (
	"context"
	"testing"

	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"gotest.tools/v3/assert"
)

var user1 User = User{"key1", "user1"}

func ensureUsers(db *mongo.Database) error {
	keys := db.Collection(KeysC)
	var existingUser User
	if err := keys.FindOne(context.TODO(), bson.M{"login": user1.Login}).Decode(&existingUser); err != nil {
		log.Debug().Err(err).Msg("Inserting user")
		_, err = keys.InsertOne(context.TODO(), user1)
		if err != nil {
			return err
		}
	}
	return nil
}

func TestSearchUser(t *testing.T) {
	db, terminate, err := MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	err = ensureUsers(db)
	assert.NilError(t, err)
	login, err := UserFromKey(user1.Key, db)
	assert.NilError(t, err)
	assert.Equal(t, user1.Login, login)
	_, err = UserFromKey("no such key", db)
	assert.Equal(t, ErrUnknownApiKey, err)
}
