package pokedex

import (
	"context"
	"encoding/json"
	"errors"
	"io/ioutil"
	"os"

	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// Damage multiplier wrt attack type
type Against struct {
	Bug      float32
	Dark     float32
	Dragon   float32
	Electric float32
	Fairy    float32
	Fight    float32
	Fire     float32
	Flying   float32
	Ghost    float32
	Grass    float32
	Ground   float32
	Ice      float32
	Normal   float32
	Poison   float32
	Psychic  float32
	Rock     float32
	Steel    float32
	Water    float32
}

type Images struct {
	Full   string
	Detail string
}

type Pokemon struct {
	Abilities        []string
	Against          Against
	Attack           int
	BaseEggSteps     int `bson:"base_egg_steps"`
	BaseHappiness    int `bson:"base_happiness"`
	BaseTotal        int `bson:"base_total"`
	CaptureRate      int `bson:"capture_rate"`
	Classification   string
	Defense          int
	ExperienceGrowth int64 `bson:"experience_growth"`
	Generation       int
	HeightM          float64 `bson:"height_m"`
	Hp               int
	Images           Images
	IsLegendary      int    `bson:"is_legendary"`
	JapaneseName     string `bson:"japanese_name"`
	Name             string
	PercentageMale   float64 `bson:"percentage_male"`
	PokedexNumber    int     `bson:"pokedex_number"`
	SpAttack         int     `bson:"sp_attack"`
	SpDefense        int     `bson:"sp_defense"`
	Speed            int
	Types            []string
	WeightKg         float64 `bson:"weight_kg"`
}

const PokedexC = "pokedex"

var ErrUnknownPokemon error = errors.New("unknown Pokemon")

func PokemonFromNumber(n int, db *mongo.Database) (Pokemon, error) {
	pokedex := db.Collection(PokedexC)
	var pokemon Pokemon
	err := pokedex.FindOne(context.TODO(), bson.M{"pokedex_number": n}, options.FindOne()).Decode(&pokemon)
	if err == mongo.ErrNoDocuments {
		return Pokemon{}, ErrUnknownPokemon
	}
	if err != nil {
		return Pokemon{}, err
	}
	return pokemon, nil
}

func Pokemons(db *mongo.Database, ctx context.Context, nameQuery string) ([]Pokemon, error) {
	//func PokemonNumbers(db *mongo.Database, ctx context.Context, nameQuery string) ([]int, error) {
	pokedex := db.Collection(PokedexC)
	var cursor *mongo.Cursor
	var err error
	if nameQuery != "" { //name: {$regex:'chu', $options:'i'}
		log.Info().Str("nameQuery", nameQuery).Msg("Getting pokemon with query")
		cursor, err = pokedex.Find(ctx,
			bson.M{"name": bson.M{"$regex": nameQuery, "$options": "i"}},
			options.Find())
	} else {
		log.Info().Msg("Getting all pokemons")
		cursor, err = pokedex.Find(ctx, bson.M{}, options.Find())
	}
	if err != nil {
		return []Pokemon{}, err
	}
	defer cursor.Close(ctx)

	var pokemons []Pokemon
	if err = cursor.All(ctx, &pokemons); err != nil {
		return []Pokemon{}, err
	}
	/*for _, n := range pokemons {
		if n.Abilities == nil {
			log.Warn().Int("number", n.PokedexNumber).Msg("Found empty abilities")
		}
		if n.PokedexNumber == 0 {
			log.Warn().Int("number", n.PokedexNumber).Msg("Found number 0")
		}
		numbers = append(numbers, n.PokedexNumber)
	}*/
	return pokemons, nil
}

func reloadPokemons(pokemons []Pokemon,
	db *mongo.Database, ctx context.Context) error {
	pCol := db.Collection(PokedexC)
	_, err := pCol.DeleteMany(ctx, bson.M{}, &options.DeleteOptions{})
	if err != nil {
		log.Err(err).Msg("Failed to delete pokedex content")
		return err
	}
	var toInsert []interface{}
	for _, pk := range pokemons {
		toInsert = append(toInsert, pk)
	}
	_, err = pCol.InsertMany(ctx, toInsert, &options.InsertManyOptions{})
	if err != nil {
		log.Err(err).Msg("Failed to insert pokedex content")
		return err
	}
	return nil
}

func LoadPokemonsFromFile(
	filename string,
	db *mongo.Database, ctx context.Context) error {
	var pokemons []Pokemon
	file, err := os.Open(filename)
	if err != nil {
		log.Err(err).Msg("Failed to open pokemon file")
		return err
	}
	defer file.Close()
	bytes, err := ioutil.ReadAll(file)
	if err != nil {
		log.Err(err).Msg("Failed to read pokemon file")
		return err
	}
	json.Unmarshal(bytes, &pokemons)
	err = reloadPokemons(pokemons, db, ctx)
	return err
}
