package pokedex

import (
	"context"
	"encoding/json"
	"errors"
	"math/rand"
	"time"

	"github.com/rs/zerolog/log"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const DeckC = "decks"

type Deck = struct {
	User     string `bson:"_id"`
	Pokemons []int
}

func rawUserDeck(userId string, db *mongo.Database, ctx context.Context) (Deck, error) {
	decks := db.Collection(DeckC)
	var noPokemons []int = []int{}
	var deck Deck = Deck{User: userId, Pokemons: noPokemons}
	err := decks.FindOne(ctx, bson.M{"_id": userId}, options.FindOne()).Decode(&deck)
	if err == mongo.ErrNoDocuments {
		return deck, nil
	} else if err != nil {
		return deck, err
	}
	return deck, nil
}

func GetUserDeck(userId string, db *mongo.Database, ctx context.Context) ([]int, error) {
	deck, err := rawUserDeck(userId, db, ctx)
	return deck.Pokemons, err
}

func SetUserDeck(userId string, pokemons []int, db *mongo.Database, ctx context.Context) ([]int, error) {
	decks := db.Collection(DeckC)
	deck := Deck{userId, pokemons}
	upsert := true
	result := decks.FindOneAndReplace(ctx, bson.M{"_id": userId}, deck, &options.FindOneAndReplaceOptions{Upsert: &upsert})
	err := result.Err()
	if err != nil && err != mongo.ErrNoDocuments {
		return []int{}, err
	} else {
		return pokemons, nil
	}
}

type Side int

const (
	Left Side = iota
	Right
)

func (s Side) String() string {
	switch s {
	case Left:
		return "left"
	case Right:
		return "right"
	}
	return "unknown"
}

var ErrUnknownSide error = errors.New("unknown side")

func (side *Side) UnmarshalJSON(data []byte) (err error) {
	var str string
	err = json.Unmarshal(data, &str)
	if err != nil {
		return err
	}
	switch str {
	case "left":
		*side = Left
		return nil
	case "right":
		*side = Right
		return nil
	default:
		return ErrUnknownSide
	}
}

func (side Side) MarshalJSON() ([]byte, error) {
	return []byte("\"" + side.String() + "\""), nil
}

type Round struct {
	Left       int
	Right      int
	AttackFrom Side
	Type       string
	Damage     int
	KO         bool
}
type FightResult struct {
	DeckLeft  Deck
	DeckRight Deck
	Winner    Side
	Rounds    []Round
}

const baseDmg float32 = 10.0

func dmg(typ string, pokemon Pokemon) int {
	switch typ {
	case "bug":
		return int(pokemon.Against.Bug * baseDmg)
	case "dark":
		return int(pokemon.Against.Dark * baseDmg)
	case "dragon":
		return int(pokemon.Against.Dragon * baseDmg)
	case "electric":
		return int(pokemon.Against.Electric * baseDmg)
	case "fairy":
		return int(pokemon.Against.Fairy * baseDmg)
	case "fight":
		return int(pokemon.Against.Fight * baseDmg)
	case "fire":
		return int(pokemon.Against.Fire * baseDmg)
	case "flying":
		return int(pokemon.Against.Flying * baseDmg)
	case "ghost":
		return int(pokemon.Against.Ghost * baseDmg)
	case "grass":
		return int(pokemon.Against.Grass * baseDmg)
	case "ground":
		return int(pokemon.Against.Ground * baseDmg)
	case "ice":
		return int(pokemon.Against.Ice * baseDmg)
	case "normal":
		return int(pokemon.Against.Normal * baseDmg)
	case "poison":
		return int(pokemon.Against.Poison * baseDmg)
	case "psychic":
		return int(pokemon.Against.Psychic * baseDmg)
	case "rock":
		return int(pokemon.Against.Rock * baseDmg)
	case "steel":
		return int(pokemon.Against.Steel * baseDmg)
	case "water":
		return int(pokemon.Against.Water * baseDmg)
	}
	return int(pokemon.Against.Normal * baseDmg)
}

func init() {
	rand.Seed(time.Now().UnixNano())
}

func attack(fromP Pokemon, toP Pokemon, hp int) (int, bool, int, string) {
	typ := fromP.Types[rand.Intn(len(fromP.Types))]
	damage := dmg(typ, toP)
	if damage <= 0 {
		damage = 1
	}
	newHp := hp - damage
	return newHp, newHp <= 0, damage, typ
}

func simulateFight(leftSide []Pokemon, rightSide []Pokemon) FightResult {
	var res FightResult
	// copy pokemon numbers in corresponding res fields
	for _, p := range leftSide {
		res.DeckLeft.Pokemons = append(res.DeckLeft.Pokemons, p.PokedexNumber)
	}
	for _, p := range rightSide {
		res.DeckRight.Pokemons = append(res.DeckRight.Pokemons, p.PokedexNumber)
	}
	leftIdx := 0
	rightIdx := 0
	hpLeft := leftSide[0].Hp
	hpRight := rightSide[0].Hp
	side := Right
	finished := false
	for !finished {
		var attacker Pokemon
		var defender Pokemon
		var curHp int
		if side == Left {
			attacker = leftSide[leftIdx]
			defender = rightSide[rightIdx]
			curHp = hpRight
		} else {
			attacker = rightSide[rightIdx]
			defender = leftSide[leftIdx]
			curHp = hpLeft
		}
		newHp, ko, damage, typ := attack(attacker, defender, curHp)
		round := Round{leftSide[leftIdx].PokedexNumber, rightSide[rightIdx].PokedexNumber, side, typ, damage, ko}
		if side == Left {
			hpRight = newHp
			if ko {
				rightIdx = rightIdx + 1
				log.Debug().Int("rightIdx", rightIdx).Int("right_size", len(rightSide)).Msg("Increased rightIdx")
				if rightIdx >= len(rightSide) {
					res.Winner = Left
					finished = true
					log.Debug().Msg("Left won")
				} else {
					hpRight = rightSide[rightIdx].Hp
				}
			}
		} else {
			hpLeft = newHp
			if ko {
				leftIdx = leftIdx + 1
				log.Debug().Int("leftIdx", leftIdx).Int("left_size", len(leftSide)).Msg("Increased leftIdx")
				if leftIdx >= len(leftSide) {
					res.Winner = Right
					finished = true
					log.Debug().Msg("Right won")
				} else {
					hpLeft = leftSide[leftIdx].Hp
				}
			}
		}
		res.Rounds = append(res.Rounds, round)
		if side == Left {
			side = Right
		} else {
			side = Left
		}
	}
	return res
}

var ErrNoDeckFound error = errors.New("could not find a deck with at least one pokemon")

// Random deck with at least one pokemon: using mongo aggregation pipeline
// [{
//     $match: {
//         $expr: {
//             $gt: [{
//                     $size: '$pokemons'
//                 },
//                 0
//             ]
//         }
//     }
// }, {
//     $sample: {
//         size: 1
//     }
// }]
func RandomDeck(db *mongo.Database, ctx context.Context) (Deck, error) {
	decks := db.Collection(DeckC)
	var deck Deck
	cursor, err := decks.Aggregate(ctx,
		bson.A{
			bson.M{"$match": bson.M{"$expr": bson.M{"$gt": bson.A{bson.M{"$size": "$pokemons"}, 0}}}},
			bson.M{"$sample": bson.M{"size": 1}}},
		&options.AggregateOptions{})
	if err != nil {
		return Deck{}, err
	}
	defer cursor.Close(ctx)
	if cursor.Next(ctx) {
		if err = cursor.Decode(&deck); err != nil {
			return Deck{}, err
		} else {
			return deck, nil
		}
	}
	return Deck{}, ErrNoDeckFound
}

const MaxPokemonInFight int = 3

func samplePokemonsFromDeck(deck Deck, db *mongo.Database, ctx context.Context) ([]Pokemon, error) {
	pokemons := deck.Pokemons
	rand.Shuffle(len(pokemons), func(i, j int) {
		pokemons[i], pokemons[j] = pokemons[j], pokemons[i]
	})
	if len(pokemons) > 3 {
		pokemons = pokemons[0:3]
	}
	pokedex := db.Collection(PokedexC)
	cursor, err := pokedex.Find(ctx, bson.M{"pokedex_number": bson.M{"$in": pokemons}}, &options.FindOptions{})
	if err == mongo.ErrNoDocuments {
		return []Pokemon{}, nil
	} else if err != nil {
		return []Pokemon{}, err
	}
	defer cursor.Close(ctx)
	var result []Pokemon
	err = cursor.All(ctx, &result)
	if err != nil {
		return []Pokemon{}, err
	}
	rand.Shuffle(len(result), func(i, j int) {
		result[i], result[j] = result[j], result[i]
	})
	return result, nil
}

func Fight(userLeft string, db *mongo.Database, ctx context.Context) (FightResult, error) {
	deckLeft, err := rawUserDeck(userLeft, db, ctx)
	if err != nil {
		return FightResult{}, err
	}
	deckRight, err := RandomDeck(db, ctx)
	if err != nil {
		return FightResult{}, err
	}
	pokemonsLeft, err := samplePokemonsFromDeck(deckLeft, db, ctx)
	if err != nil {
		return FightResult{}, err
	}
	pokemonsRight, err := samplePokemonsFromDeck(deckRight, db, ctx)
	if err != nil {
		return FightResult{}, err
	}
	result := simulateFight(pokemonsLeft, pokemonsRight)
	result.DeckLeft.User = deckLeft.User
	result.DeckRight.User = deckRight.User
	return result, nil
}
