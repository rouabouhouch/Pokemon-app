package pokedex

import (
	"context"
	"fmt"
	"testing"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/config"
	"gotest.tools/v3/assert"
)

func init() {
	config.InitConfig()
}

func TestCanGetPokemon(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	pokemon, err := PokemonFromNumber(1, db)
	assert.NilError(t, err)
	assert.Equal(t, pokemon.Name, "Bulbasaur")
	pokemon, err = PokemonFromNumber(-1, db)
	assert.Equal(t, err, ErrUnknownPokemon)
}

func TestGetPokemons(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	pokemons, err := Pokemons(db, context.TODO(), "")
	assert.NilError(t, err)
	assert.Equal(t, len(pokemons), 801)
	min := pokemons[0].PokedexNumber
	max := pokemons[0].PokedexNumber
	fmt.Printf("min: %d\n", min)
	for _, v := range pokemons {
		if v.PokedexNumber > max {
			max = v.PokedexNumber
		}
		if v.PokedexNumber < min {
			// fmt.Printf("Update min: t[%d]=%d", i, v)
			min = v.PokedexNumber
		}
	}
	assert.Equal(t, min, 1)
	assert.Equal(t, max, 801)
}
