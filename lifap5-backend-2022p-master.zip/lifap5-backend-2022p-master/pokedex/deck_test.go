package pokedex

import (
	"context"
	"testing"

	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/backend"
	"forge.univ-lyon1.fr/inf2026l-lifap5/lifap5-backend-2022p/config"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"gotest.tools/v3/assert"
)

func init() {
	config.InitConfig()
}

func ensureDeck(db *mongo.Database, ctx context.Context) (Deck, error) {
	decks := db.Collection(DeckC)
	deck := Deck{"deck-user0", []int{1, 5, 13, 20}}
	upsert := true
	result := decks.FindOneAndReplace(ctx, bson.M{"_id": deck.User}, deck, &options.FindOneAndReplaceOptions{Upsert: &upsert})
	err := result.Err()
	if err == mongo.ErrNoDocuments {
		err = nil
	}
	return deck, err
}

func flushDecks(db *mongo.Database, ctx context.Context) error {
	decks := db.Collection(DeckC)
	_, err := decks.DeleteMany(ctx, bson.M{}, &options.DeleteOptions{})
	return err
}

func TestCreateReadDeck(t *testing.T) {
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	user := "deck-user1"
	ctx := context.Background()
	err = flushDecks(db, ctx)
	assert.NilError(t, err, "Failed to cleanup user info before test case")
	readPokemons, err := GetUserDeck(user, db, ctx)
	assert.NilError(t, err, "Failed to read pokemon deck")
	assert.Equal(t, 0, len(readPokemons), "Wrong length for pokemons in db")
	pokemons := []int{1, 7, 12}
	_, err = SetUserDeck(user, pokemons, db, ctx)
	assert.NilError(t, err, "Failed to insert deck data")
	readPokemons, err = GetUserDeck(user, db, ctx)
	assert.NilError(t, err, "Failed to read pokemon deck")
	assert.DeepEqual(t, pokemons, readPokemons)
	err = flushDecks(db, ctx)
	assert.NilError(t, err)
}

func TestRandomDeck(t *testing.T) {
	ctx := context.Background()
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	err = flushDecks(db, ctx)
	assert.NilError(t, err, "Failed to cleanup user info before test case")
	_, err = ensureDeck(db, ctx)
	assert.NilError(t, err)
	deck2, err := RandomDeck(db, ctx)
	assert.NilError(t, err)
	assert.Assert(t, len(deck2.Pokemons) > 0)
	err = flushDecks(db, ctx)
	assert.NilError(t, err)
	_, err = RandomDeck(db, ctx)
	assert.Equal(t, err, ErrNoDeckFound)
}

func TestSamplePokemonsFromDeck(t *testing.T) {
	ctx := context.Background()
	db, terminate, err := backend.MongoConnect()
	assert.NilError(t, err, "Failed to connect to Mongo")
	defer terminate()
	err = flushDecks(db, ctx)
	assert.NilError(t, err, "Failed to cleanup user info before test case")
	deck, err := ensureDeck(db, ctx)
	assert.NilError(t, err)
	pokemons, err := samplePokemonsFromDeck(deck, db, ctx)
	assert.NilError(t, err)
	assert.Assert(t, len(pokemons) > 0)
	assert.Assert(t, len(pokemons) <= 3)
}
