#!/usr/bin/env bash
#opts=""
#test -z "$MONGO_USER" || opts="$opts -u $MONGO_USER"
#test -z "$MONGO_PASSWORD" || opts="$opts -p $MONGO_PASSWORD"
#mongoimport $opts --drop --db=lifap5 --collection=pokedex --jsonArray mongodb://localhost:27017/?authSource=admin $(dirname $0)/data/pokedex.json
# docker-compose exec mongodb mongoimport $opts --drop --db=lifap5 --collection=pokedex --jsonArray < data/pokedex.json

test -n "$datadir" || datadir=data
test -n "$dumpfile" || dumpfile=pokemons-dump.json
test -n "$userfileprefix" || userfileprefix=users
test -n "$idcol" || idcol=ID
test -n "$keycol" || keycol=cle_api

set -e # exit when command fails

docker compose cp $datadir/$dumpfile pokedex:/
docker compose exec pokedex /opt/lifap5-backend-2022p loadPokedex $dumpfile

for f in "$datadir/$userfileprefix"*.tsv
do
    docker compose cp $f pokedex:/
    docker compose exec pokedex /opt/lifap5-backend-2022p keys --key-col $keycol --id-col $idcol $(basename $f)
done
