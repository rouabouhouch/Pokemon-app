docker build . -t lifap5/server-2022p -t harbor.pagoda.os.univ-lyon1.fr/ecoquery-enseignement/lifap5/server-2022p
